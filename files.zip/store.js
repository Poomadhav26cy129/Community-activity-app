// Data layer. Everything the UI needs goes through this object.
// Now: localStorage (syncs across tabs on one device).
// For real multi-user: replace the bodies with fetch() calls to a backend / Firebase / Supabase.
const Store={
 K:'caa-v1',
 load(){try{return JSON.parse(localStorage.getItem(this.K))||{users:[],reports:[],ideas:[]}}catch(e){return{users:[],reports:[],ideas:[]}}},
 save(d){localStorage.setItem(this.K,JSON.stringify(d))},
 update(fn){const d=this.load();fn(d);this.save(d);return d},
 session(v){if(v===undefined)return localStorage.getItem('caa-me');v?localStorage.setItem('caa-me',v):localStorage.removeItem('caa-me')},
 onChange(cb){addEventListener('storage',cb);setInterval(cb,5000)} // 5s poll = placeholder for live updates
};
