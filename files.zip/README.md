# Community Activity App – Frontend
Open `index.html` in a browser (or `npx serve .`). Mobile-first, no build step.
Files: `store.js` (data layer – swap for a real backend), `app.js` (UI + gamification), `style.css`.
Points: report +10, photo +5, solve +25, idea +15, advice +5.
