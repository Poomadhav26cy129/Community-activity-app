const COST={Pothole:[3000,8000],Streetlight:[2500,5000],Garbage:[1000,3000],'Water leak':[5000,12000],Drainage:[8000,20000],Other:[1000,5000]};
const RANKS=[[0,'Newcomer'],[50,'Helper'],[150,'Guardian'],[400,'Champion'],[800,'Legend']];
const PTS={report:10,photo:5,solve:25,idea:15,advice:5};
const AVS=['🙂','😎','🦁','🐯','🦊','🐼','🌟','🚀'];
const $=s=>document.querySelector(s),e=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const inr=n=>'₹'+n.toLocaleString('en-IN');
let tab='map',pick=null,map,markers=[],photo=null;

const me=()=>Store.load().users.find(u=>u.id===Store.session());
const rank=u=>{let r=RANKS[0],n=null;RANKS.forEach((x,i)=>{if(u.points>=x[0]){r=x;n=RANKS[i+1]}});return{name:(u.student&&u.ideas>=1?'Student ':'')+r[1],next:n,base:r[0]}};
function badges(u){const b=[];[[1,'📣','First Report'],[5,'📢','Reporter x5']].forEach(x=>u.reports>=x[0]&&b.push(x[1]+' '+x[2]));
 [[1,'🔧','Problem Solver'],[5,'🛠️','Fixer x5']].forEach(x=>u.solved>=x[0]&&b.push(x[1]+' '+x[2]));
 [[1,'💡','Idea Spark'],[3,'🧠','Innovator']].forEach(x=>u.ideas>=x[0]&&b.push(x[1]+' '+x[2]));
 if(u.student)b.push('🎓 Student');return b}
const award=(d,id,k,p)=>{const u=d.users.find(x=>x.id===id);if(u){u.points+=p;if(k)u[k]++}};
const av=u=>u.pic?`<img class="av" src="${u.pic}">`:`<div class="av">${u.avatar}</div>`;
const who=(d,id)=>d.users.find(u=>u.id===id)||{name:'?',avatar:'🙂',points:0};

function resize(file,cb,max=600){const r=new FileReader();r.onload=()=>{const i=new Image();i.onload=()=>{const s=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=i.width*s;c.height=i.height*s;c.getContext('2d').drawImage(i,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',.7))};i.src=r.result};r.readAsDataURL(file)}

function render(){const u=me();if(!u)return login();
 const nav=[['map','🗺️','Map'],['dash','📊','Dashboard'],['ideas','💡','Ideas'],['top','🏆','Ranks'],['me','👤','Me']];
 $('#app').innerHTML=`<main id="v"></main><nav>${nav.map(n=>`<button class="${tab==n[0]?'on':''}" onclick="go('${n[0]}')">${n[1]}<br>${n[2]}</button>`).join('')}</nav>`;
 ({map:vMap,dash:vDash,ideas:vIdeas,top:vTop,me:vMe})[tab](u)}
function go(t){tab=t;pick=null;photo=null;render()}

function login(){let reg=false;const draw=()=>{$('#app').innerHTML=`<main><div class="card"><h2>🏘️ Community Activity</h2><p class="mut">Report problems. Fix them. Earn ranks.</p>
 <input id="n" placeholder="Username"><input id="p" type="password" placeholder="Password">
 ${reg?'<label class="row"><input id="st" type="checkbox" style="width:auto"> I am a student</label>':''}
 <button id="go">${reg?'Create account':'Log in'}</button><button class="alt" id="sw">${reg?'I have an account':'New here? Sign up'}</button><small id="err" style="color:#c0392b"></small></div></main>`;
 $('#sw').onclick=()=>{reg=!reg;draw()};
 $('#go').onclick=()=>{const n=$('#n').value.trim(),p=$('#p').value;if(!n||!p)return $('#err').textContent='Fill both fields';
  const d=Store.load(),f=d.users.find(u=>u.name.toLowerCase()==n.toLowerCase());
  if(reg){if(f)return $('#err').textContent='Name taken';const id='u'+Date.now();
   Store.update(d=>d.users.push({id,name:n,pw:btoa(p),avatar:AVS[Math.random()*8|0],pic:null,student:$('#st').checked,points:0,reports:0,solved:0,ideas:0}));Store.session(id)}
  else{if(!f||f.pw!==btoa(p))return $('#err').textContent='Wrong name or password';Store.session(f.id)}
  render()}};draw()}

function vMap(u){const d=Store.load();$('#v').innerHTML=`<div id="map"></div><div id="form" class="card"><b>Tap the map to drop a pin</b></div>`;
 map=L.map('map').setView([11.1085,77.3411],14);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
 drawPins(d);map.on('click',ev=>{pick=ev.latlng;if(window._pm)map.removeLayer(window._pm);window._pm=L.marker(pick).addTo(map);reportForm()})}
function drawPins(d){markers.forEach(m=>map.removeLayer(m));markers=d.reports.map(r=>L.circleMarker([r.lat,r.lng],{radius:10,color:r.status=='solved'?'#1f9d63':'#e8590c',fillOpacity:.8}).addTo(map).bindPopup(card(d,r)+(r.status=='open'?`<button class="sm" onclick="solve('${r.id}')">Mark solved +25</button>`:'')))}
function card(d,r){const [a,b]=COST[r.cat];return `<b>${e(r.cat)}</b> <span class="tag ${r.status=='open'?'open':''}">${r.status}</span><br>${e(r.desc)}<br><small>by ${e(who(d,r.by).name)} · est. ${inr(a)}–${inr(b)}</small>${r.photo?`<img class="proof" src="${r.photo}">`:''}`}
function reportForm(){$('#form').innerHTML=`<b>Report a problem here</b><select id="c">${Object.keys(COST).map(c=>`<option>${c}</option>`).join('')}</select>
 <textarea id="d" rows="2" placeholder="What's wrong?"></textarea><small id="est" class="mut"></small>
 <label class="mut">📷 Add photo proof (optional)<input id="ph" type="file" accept="image/*" capture="environment"></label><div id="pv"></div>
 <button id="sub">Submit report (+10 pts)</button>`;
 const est=()=>{const [a,b]=COST[$('#c').value];$('#est').textContent=`Estimated cost to fix: ${inr(a)}–${inr(b)}`};$('#c').onchange=est;est();
 $('#ph').onchange=ev=>{const f=ev.target.files[0];if(f)resize(f,x=>{photo=x;$('#pv').innerHTML=`<img class="proof" src="${x}">`})};
 $('#sub').onclick=()=>{if(!$('#d').value.trim())return alert('Add a short description');
  Store.update(d=>{d.reports.push({id:'r'+Date.now(),by:me().id,lat:pick.lat,lng:pick.lng,cat:$('#c').value,desc:$('#d').value.trim(),photo,status:'open',t:Date.now()});award(d,me().id,'reports',PTS.report+(photo?PTS.photo:0))});photo=null;pick=null;render()}}
function solve(id){Store.update(d=>{const r=d.reports.find(x=>x.id==id);if(r&&r.status=='open'){r.status='solved';r.solvedBy=me().id;award(d,me().id,'solved',PTS.solve)}});render()}

function vDash(){const d=Store.load(),open=d.reports.filter(r=>r.status=='open'),sol=d.reports.length-open.length;
 const cost=open.reduce((s,r)=>s+(COST[r.cat][0]+COST[r.cat][1])/2,0);
 $('#v').innerHTML=`<h2>Area dashboard</h2><div class="grid"><div class="card"><div class="big">${open.length}</div>Open problems</div><div class="card"><div class="big">${sol}</div>Solved</div>
 <div class="card"><div class="big">${d.users.length}</div>Members</div><div class="card"><div class="big">${inr(cost)}</div>Est. cost to fix open ones</div></div>
 <div class="card"><b>By category</b>${Object.keys(COST).map(c=>{const n=d.reports.filter(r=>r.cat==c).length;return `<div class="row"><span style="width:100px">${c}</span><div class="bar" style="flex:1"><i style="width:${d.reports.length?n/d.reports.length*100:0}%"></i></div><small>${n}</small></div>`}).join('')}</div>
 <h3>Recent activity</h3>${d.reports.slice(-8).reverse().map(r=>`<div class="card">${card(d,r)}</div>`).join('')||'<p class="mut">No reports yet. Drop the first pin!</p>'}
 <small class="mut">Costs are rough estimates for planning only.</small>`}

function vIdeas(u){const d=Store.load();$('#v').innerHTML=`<h2>Ideas & advice</h2>${u.student?`<div class="card"><b>🎓 Share your idea (+15)</b><input id="t" placeholder="Idea title"><textarea id="x" rows="3" placeholder="Describe it"></textarea><button id="si">Post idea</button></div>`:'<p class="mut">Students post ideas. Everyone can give advice (+5).</p>'}
 ${d.ideas.slice().reverse().map(i=>`<div class="card"><b>${e(i.title)}</b> <span class="tag">🎓 ${e(who(d,i.by).name)}</span><p>${e(i.text)}</p>${i.adv.map(a=>`<small>💬 <b>${e(who(d,a.by).name)}:</b> ${e(a.text)}</small><br>`).join('')}
 <div class="row"><input placeholder="Give advice" id="a${i.id}"><button class="sm" onclick="advise('${i.id}')">Send</button></div></div>`).join('')}`;
 if(u.student)$('#si').onclick=()=>{const t=$('#t').value.trim(),x=$('#x').value.trim();if(!t||!x)return;Store.update(d=>{d.ideas.push({id:'i'+Date.now(),by:u.id,title:t,text:x,adv:[]});award(d,u.id,'ideas',PTS.idea)});render()}}
function advise(id){const t=$('#a'+id).value.trim();if(!t)return;Store.update(d=>{d.ideas.find(i=>i.id==id).adv.push({by:me().id,text:t});award(d,me().id,null,PTS.advice)});render()}

function vTop(){const d=Store.load();$('#v').innerHTML=`<h2>Leaderboard</h2>`+d.users.slice().sort((a,b)=>b.points-a.points).map((u,i)=>`<div class="card row">${i+1}. ${av(u)}<div style="flex:1"><b>${e(u.name)}</b><br><small>${rank(u).name}</small></div><b>${u.points}</b></div>`).join('')}

function vMe(u){const r=rank(u),pc=r.next?(u.points-r.base)/(r.next[0]-r.base)*100:100;
 $('#v').innerHTML=`<div class="card row">${av(u)}<div><h2>${e(u.name)}</h2><span class="tag">${r.name}</span></div></div>
 <div class="card"><b>${u.points} points</b>${r.next?` <small>· ${r.next[0]-u.points} to ${r.next[1]}</small>`:''}<div class="bar"><i style="width:${pc}%"></i></div>
 <small>${u.reports} reports · ${u.solved} solved · ${u.ideas} ideas</small></div>
 <div class="card"><b>Badges</b><br>${badges(u).map(b=>`<span class="tag">${b}</span>`).join('')||'<small class="mut">Report something to earn your first badge</small>'}</div>
 <div class="card"><b>Personalize</b><input id="nn" value="${e(u.name)}"><div class="row" style="flex-wrap:wrap">${AVS.map(a=>`<button class="alt sm" onclick="setAv('${a}')">${a}</button>`).join('')}</div>
 <label class="mut">Upload profile photo<input id="pp" type="file" accept="image/*"></label><button id="sv">Save name</button><button class="alt" id="lo">Log out</button></div>`;
 $('#sv').onclick=()=>{const n=$('#nn').value.trim();if(n)Store.update(d=>{d.users.find(x=>x.id==u.id).name=n});render()};
 $('#pp').onchange=ev=>resize(ev.target.files[0],x=>{Store.update(d=>{d.users.find(y=>y.id==u.id).pic=x});render()},150);
 $('#lo').onclick=()=>{Store.session(null);render()}}
function setAv(a){Store.update(d=>{const u=d.users.find(x=>x.id==Store.session());u.avatar=a;u.pic=null});render()}

Store.onChange(()=>{if(!me())return;if(tab=='map'&&map&&!pick)drawPins(Store.load());else if(tab!='map'&&!document.activeElement.matches('input,textarea,select'))render()});
render();
